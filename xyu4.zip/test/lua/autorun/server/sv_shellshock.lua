local shellshock_duration = CreateConVar("shellshock_duration", 4.5, FCVAR_ARCHIVE, "Duration of the shell shock after an explosion", 0, 60)

hook.Add("PlayerSpawn", "shellshock_ensure", function(ply)
    if ply:GetShellShocked() then
        ply:SetShellShocked(false)
    end
end)

hook.Add("PostEntityTakeDamage", "shellshock_boomboom", function(ent, dmg, took)
    if not GetConVar("shellshock_enabled"):GetBool() then return end
    if not shellshock_duration:GetBool() then return end
    if not took then return end
    if not ent:IsPlayer() then return end

    if dmg:GetDamageType() == DMG_BLAST or dmg:GetDamageType() == DMG_BLAST_SURFACE or dmg:GetDamageType() == DMG_MISSILEDEFENSE then
        ent:SetShellShocked(true)
        timer.Simple(hook.Run("GetShellShockDuration", ent, dmg, took) or shellshock_duration:GetFloat(), function()
            if not IsValid(ent) then return end
            if not ent:Alive() then return end
            if not ent:GetShellShocked() then return end

            ent:SetShellShocked(false)
        end)
    end
end)