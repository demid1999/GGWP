local shellshock_enabled = CreateConVar("shellshock_enabled", 1, FCVAR_ARCHIVE + FCVAR_REPLICATED, "Enables shell shocking", 0, 1)
local shellshock_speedmp = CreateConVar("shellshock_speedmp", 0.25, FCVAR_ARCHIVE + FCVAR_REPLICATED, "Speed multiplier when shellshocked", 0, 1)

local meta = FindMetaTable("Player")

function meta:GetShellShocked()
    return self.m_bShellShocked
end

if SERVER then
    util.AddNetworkString("shellshock_status")
end
function meta:SetShellShocked(status)
    status = tobool(status)
    if status == self.m_bShellShocked then return end

    self.m_bShellShocked = status

    hook.Run("PlayerShellShocked", self, status)

    if SERVER then
        net.Start("shellshock_status")
        net.WriteEntity(self)
        net.WriteBool(status)
        net.Broadcast()
    end
end

if CLIENT then
    net.Receive("shellshock_status", function()
        local ply = net.ReadEntity()
        local status = net.ReadBool()

        ply:SetShellShocked(status)
    end)
end

hook.Add("SetupMove", "shellshock_shank", function(ply, mv)
    if not IsValid(ply) then return end
    if ply:GetShellShocked() and mv:GetMaxClientSpeed() ~= 100 then
        ply.OldClientSpeed = mv:GetMaxClientSpeed()
        mv:SetMaxClientSpeed(100)
    elseif not ply:GetShellShocked() and mv:GetMaxClientSpeed() == 100 then
        if ply.OldClientSpeed then
            mv:SetMaxClientSpeed(ply.OldClientSpeed)
        end
    end
end)
