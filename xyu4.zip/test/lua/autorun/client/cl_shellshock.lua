local shellshock_soundpreference = CreateConVar("shellshock_soundpreference", 2, FCVAR_ARCHIVE, "Which variant of the shellshock exit sound will play?", 1, 2)

hook.Add("RenderScreenspaceEffects", "shellshock_effects", function()
    if not GetConVar("shellshock_enabled"):GetBool() then return end
    local obs = LocalPlayer():GetObserverTarget()
    local ply = IsValid(obs) and obs or LocalPlayer()

    ply.ShellMP = ply.ShellMP or 0
    ply.TargetShellMP = ply.TargetShellMP or 0

    if ply.ShellMP ~= 0 then
        DrawMotionBlur(0.1245, 0.75 * ply.ShellMP, 0.0125)
        DrawColorModify({
            ["$pp_colour_addr"] = 0,
            ["$pp_colour_addg"] = 0,
            ["$pp_colour_addb"] = 0,
            ["$pp_colour_brightness"] = 0,
            ["$pp_colour_contrast"] = 1,
            ["$pp_colour_colour"] = 1 - ply.ShellMP,
            ["$pp_colour_mulr"] = 0,
            ["$pp_colour_mulg"] = 0,
            ["$pp_colour_mulb"] = 0
        })
    end

    ply.ShellMP = Lerp(FrameTime() * 1.5, ply.ShellMP, ply.TargetShellMP)
end)

hook.Add("PlayerShellShocked", "shellshock_client", function(ply, status)
    if not GetConVar("shellshock_enabled"):GetBool() then return end
    ply.TargetShellMP = status and 1 or 0

    if not ply.LoopShockSound then
        ply.LoopShockSound = CreateSound(ply, "shellshock.loop")
    end
end)

hook.Add("InputMouseApply", "shellshock_mouserestrict", function(ucmd, x, y, ang)
    if not GetConVar("shellshock_enabled"):GetBool() then return end
    if LocalPlayer():GetShellShocked() then
        ang.p = ang.p + math.Clamp(y * RealFrameTime(), -10, 10)
        ang.y = ang.y - math.Clamp(x * RealFrameTime(), -10, 10)

        ucmd:SetViewAngles(ang)

        return true
    end
end)